import { Server } from "socket.io";
import products from "../src/productManager.js";


let io;

// const listProducts = await products.get();
// console.log(listProducts);

const init = (httpserver) => {
    
    io = new Server(httpserver);

    io.on('connection', (socketClient)=> {
console.log("nuevo cliente socket conectado: "+socketClient.id);
    })
};

// module.exports = init ;

export default init;